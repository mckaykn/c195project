Client Scheduler
McKay Nielson
04/10/2023
    The Client Scheduler's purpose is to allow a company to create customers,
and manage their appointments with Contacts. It includes functionality to allow
a user to add, edit, and delete customers and their appointments.
IDE - IntelliJ 2022.2.1
External Libraries - Java SE 17.0.4.1, JavaFX-SDK-17.0.2, annotations-23.0.0,
jsr-310-ri-0.6.3, opentest4j-1.2.0
MYSQL - mysql-connector-java-8.0.25

Additional Report - Within the UI there is a PieChart data object containing
the shared amount of Appointments per Contact. This could allow a company to
allocate their resources(Contacts) better.
