Client Scheduler
McKay Nielson
Contact @mniel58@wgu.edu
04/12/2023
Version 1.1
    The Client Scheduler's purpose is to allow a company to create customers,
and manage their appointments with Contacts. It includes functionality to allow
a user to add, edit, and delete customers and their appointments.
IDE - IntelliJ 2022.2.1
External Libraries - Java SE 17.0.4.1, JavaFX-SDK-17.0.2, annotations-23.0.0,
 opentest4j-1.2.0
MYSQL - mysql-connector-java-8.0.25

To run application Log-In with UserName and Password, use the add, edit, and delete
buttons to manipulate customer and appointment details. The View reports button
can also be used to show details about number of appointments per Contact, and
which contact has which appointments.

Additional Report - Within the UI there is a PieChart data object containing
the shared amount of Appointments per Contact. This could allow a company to
allocate their resources(Contacts) better.
